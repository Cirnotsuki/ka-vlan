// 自定义三列布局：左栏 / 折叠钮列(36) / 右栏，左右严格等宽。
// 不用 walk 内置布局，是因为它们按 size hint 自由分配，带 greedy 子控件的栏会抢宽度。
package main

import (
	"github.com/lxn/walk"
)

const (
	uiMargin = 8  // 四周留白
	uiGap    = 6  // 栏间距
	uiMidW   = 36 // 折叠钮列宽
	uiMinW   = 280
)

// threeColLayout 实现 walk.Layout。
type threeColLayout struct {
	walk.LayoutBase
}

func (l *threeColLayout) Create() (walk.Layout, error) { return l, nil }

// 覆写 SetContainer/Container：LayoutBase.SetContainer 会把 LayoutBase.layout（包外不可写，恒为 nil）
// 反向 SetLayout 到容器上，把 declarative 刚设置的布局抹掉，导致窗口创建链在 tooltip 注册时崩溃。
func (l *threeColLayout) SetContainer(value walk.Container) {}

func (l *threeColLayout) Container() walk.Container { return nil }

func (l *threeColLayout) CreateLayoutItem(ctx *walk.LayoutContext) walk.ContainerLayoutItem {
	panels := [3]*walk.Composite{leftPanel, midPanel, rightPanel}
	var children []walk.LayoutItem
	item := &threeColItem{}
	for i, p := range panels {
		if p == nil {
			continue
		}
		ci := p.CreateLayoutItem(ctx).(walk.ContainerLayoutItem)
		item.items[i] = ci
		children = append(children, ci)
	}
	item.SetChildren(children)
	return item
}

// threeColItem 实现 walk.ContainerLayoutItem。
type threeColItem struct {
	walk.ContainerLayoutItemBase
	items [3]walk.ContainerLayoutItem // 0=左 1=中 2=右
}

func (li *threeColItem) LayoutFlags() walk.LayoutFlags {
	return walk.ShrinkableHorz | walk.ShrinkableVert |
		walk.GrowableHorz | walk.GrowableVert |
		walk.GreedyHorz | walk.GreedyVert
}

func (li *threeColItem) MinSize() walk.Size {
	return walk.Size{Width: uiMinW*2 + uiMidW + uiGap*2 + uiMargin*2, Height: 400}
}

func (li *threeColItem) MinSizeForSize(size walk.Size) walk.Size { return size }

func (li *threeColItem) HasHeightForWidth() bool { return false }

func (li *threeColItem) HeightForWidth(int) int { return 0 }

// PerformLayout：左 = 右 = (客户区宽 - 2*margin - 36 - 2*gap) / 2，垂直撑满。
func (li *threeColItem) PerformLayout() []walk.LayoutResultItem {
	cs := li.Geometry().ClientSize
	if cs.Width <= 0 || cs.Height <= 0 {
		return nil
	}
	half := (cs.Width - uiMargin*2 - uiMidW - uiGap*2) / 2
	if half < uiMinW {
		half = uiMinW
	}
	h := cs.Height - uiMargin*2
	out := make([]walk.LayoutResultItem, 0, 3)
	if li.items[0] != nil {
		out = append(out, walk.LayoutResultItem{Item: li.items[0], Bounds: walk.Rectangle{X: uiMargin, Y: uiMargin, Width: half, Height: h}})
	}
	if li.items[1] != nil {
		out = append(out, walk.LayoutResultItem{Item: li.items[1], Bounds: walk.Rectangle{X: uiMargin + half + uiGap, Y: uiMargin, Width: uiMidW, Height: h}})
	}
	if li.items[2] != nil {
		out = append(out, walk.LayoutResultItem{Item: li.items[2], Bounds: walk.Rectangle{X: uiMargin + half + uiGap + uiMidW + uiGap, Y: uiMargin, Width: half, Height: h}})
	}
	return out
}
