// UI 线程定时器：win32 SetTimer + 子类化主窗口 WndProc。
// 不用 goroutine+walk.Synchronize：该组合在本环境会静默退出进程（原因未明，已实测复现）。
package main

import (
	"syscall"
	"unsafe"

	"github.com/lxn/walk"
	"github.com/lxn/win"
)

const hubTimerID = 7 // WM_TIMER id

var prevWndProc uintptr
var hubTimerOn bool

func startHubUITimer() {
	if hubTimerOn || mainWin == nil {
		return
	}
	hwnd := mainWin.Handle()
	if hwnd == 0 {
		return
	}
	prevWndProc = win.SetWindowLongPtr(hwnd, win.GWLP_WNDPROC, syscall.NewCallback(hubWndProc))
	win.SetTimer(hwnd, hubTimerID, 3000, 0)
	hubTimerOn = true
}

func hubWndProc(hwnd win.HWND, msg uint32, wParam, lParam uintptr) uintptr {
	if msg == win.WM_TIMER && wParam == hubTimerID {
		// UI 线程内刷新，天然安全
		if srv != nil && hubShown && !collapsed {
			n := len(srv.Members())
			if n != hubRowsSnapshot {
				hubRowsSnapshot = n
				refreshHub()
			}
		}
		return 0
	}
	return win.CallWindowProc(prevWndProc, hwnd, msg, wParam, lParam)
}

// hubRowsSnapshot 上次刷新时的成员数。
var hubRowsSnapshot = -1

var _ = unsafe.Pointer(nil)
var _ walk.Form = nil
