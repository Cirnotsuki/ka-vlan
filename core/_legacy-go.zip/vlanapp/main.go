// vlanapp 双栏 GUI：左栏 Join（昵称/IP/端口）与 Vlan Hub，右栏 Start Serve 与连接状态。
package main

import (
	"fmt"
	"log"
	"net"
	"os"
	"os/exec"
	"path/filepath"
	"strconv"
	"strings"
	"sync"
	"time"

	"github.com/lxn/walk"
	. "github.com/lxn/walk/declarative"

	"vlan/api"
	"vlan/applog"
	"vlan/client"
	"vlan/confgen"
	"vlan/server"
)

const (
	defaultPort = 1212
	defaultWG   = api.DefaultWGPort
	serverVPNIP = "10.84.111.1"
	colorOK     = 0x008000 // 绿
	colorBad    = 0x0000CC // 红
)

var (
	// 左栏（Join 侧）
	nickEdit *walk.LineEdit
	ipEdit   *walk.LineEdit
	portEdit *walk.LineEdit
	joinBtn  *walk.PushButton
	// 左栏（Hub 侧）
	hubText *walk.TextEdit
	pubEdit *walk.LineEdit
	// 折叠钮
	collapseBtn *walk.PushButton
	// 右栏
	servePortEdit     *walk.LineEdit
	serveComposite    *walk.Composite
	joinInfoComposite *walk.Composite
	lblServer         *walk.Label
	lblLatency        *walk.Label
	lblPort           *walk.Label
	lblSelf           *walk.Label
	lblMembers        *walk.Label

	// 运行态
	srv          *server.Server
	hubShown     bool // 左栏当前显示 hub 还是 join 表单
	collapsed    bool
	joinH        *client.Handle
	mode         string // "idle" | "serve" | "join"
	lastJoinOpts client.Options
)

func main() {
	_ = applog.Init()
	defer func() {
		if msg := applog.Recover("main"); msg != "" {
			walk.MsgBox(nil, "崩溃", msg, walk.MsgBoxIconError)
		}
	}()
	mw := new(walk.MainWindow)
	mainWin = mw

	err := MainWindow{
		AssignTo: &mw,
		Title:    "VLAN 组网",
		MinSize:  Size{Width: 980, Height: 480},                                                // ← 整窗最小尺寸
		Layout:   HBox{Margins: Margins{Left: 12, Top: 12, Right: 12, Bottom: 12}, Spacing: 8}, // ← 栏间间距 8 / 窗口内边距 12
		Children: []Widget{
			// ===== 左栏（等宽） =====
			Composite{
				AssignTo: &leftPanel,
				MinSize:  Size{Width: 400},
				MaxSize:  Size{Width: 1800},
				Layout:   VBox{},
				Children: []Widget{
					// Join 表单（Start Serve 后隐藏，换 Hub 列表）
					Composite{
						AssignTo: &joinFormComposite,
						Layout:   VBox{},
						Children: []Widget{
							Label{Text: "昵称（留空 = 匿名）:"},
							LineEdit{AssignTo: &nickEdit, CueBanner: "匿名"},
							Composite{
								Layout: HBox{},
								Children: []Widget{
									Label{Text: "IP:"},
									LineEdit{AssignTo: &ipEdit, CueBanner: "1.2.3.4", MinSize: Size{Width: 160}}, // ← IP 框最小宽
								Label{Text: "端口:"},
								LineEdit{AssignTo: &portEdit, Text: strconv.Itoa(defaultPort), MaxLength: 5, MinSize: Size{Width: 576}}, // ← 端口框最小宽（72×8）
								},
							},
							PushButton{AssignTo: &joinBtn, Text: "Join Server", MinSize: Size{Height: 32}, OnClicked: onJoinServe},
						},
					},
					// Hub 列表（Start Serve 后显示）
					Composite{
						AssignTo: &hubComposite,
						Visible:  false,
						Layout:   VBox{},
						Children: []Widget{
							Label{Text: "VLAN Hub · 成员管理（监听 :" + strconv.Itoa(defaultPort) + "）"},
							TextEdit{
								AssignTo: &hubText,
								ReadOnly: true,
							},
							Composite{
								Layout: HBox{},
								Children: []Widget{
									Label{Text: "公钥:"},
									LineEdit{AssignTo: &pubEdit, CueBanner: "粘贴成员 public_key"},
									PushButton{Text: "删除", OnClicked: onRowDelete},
									PushButton{Text: "封禁", OnClicked: onRowBan},
									PushButton{Text: "刷新", OnClicked: func() { refreshHub() }},
								},
							},
						},
					},
				},
			},
			// ===== 折叠钮（>> / <<），固定 36 宽 =====
			Composite{
				AssignTo: &midPanel,
				MinSize:  Size{Width: 36},
				MaxSize:  Size{Width: 36},
				Layout:   VBox{},
				Children: []Widget{
					PushButton{
						AssignTo:  &collapseBtn,
						Text:      ">>",
						MaxSize:   Size{Width: 36, Height: 2000},
						Visible:   false,
						OnClicked: onCollapse,
					},
				},
			},
			// ===== 右栏（等宽） =====
			Composite{
				AssignTo: &rightPanel,
				MinSize:  Size{Width: 400},
				MaxSize:  Size{Width: 1800},
				Layout:   VBox{},
				Children: []Widget{
					// Start Serve 表单
					Composite{
						AssignTo: &serveComposite,
						Layout:   VBox{},
						Children: []Widget{
							Label{Text: "公网服务器"},
							VSpacer{Size: 8},
							PushButton{Text: "Start Serve", MinSize: Size{Height: 36}, OnClicked: onStartServe},
							VSpacer{Size: 8},
							Label{Text: "监听端口:"},
							LineEdit{AssignTo: &servePortEdit, Text: strconv.Itoa(defaultPort), MaxLength: 5},
							VSpacer{Size: 20},
							PushButton{Text: "打开日志目录", OnClicked: func() { exec.Command("explorer", applog.LogDir).Start() }},
						},
					},
					// Join 后的状态面板
					Composite{
						AssignTo: &joinInfoComposite,
						Visible:  false,
						Layout:   VBox{},
						Children: []Widget{
							Label{Text: "—— 服务器状态 ——"},
							VSpacer{Size: 6},
							Label{AssignTo: &lblServer, Text: "服务器: -"},
							Label{AssignTo: &lblSelf, Text: "我的内网 IP: -"},
							Label{AssignTo: &lblMembers, Text: "成员数: -"},
							VSpacer{Size: 6},
							Label{AssignTo: &lblLatency, Text: "延迟: -"},
							Label{AssignTo: &lblPort, Text: "端口状态: -"},
							VSpacer{},
							PushButton{Text: "断开", MinSize: Size{Height: 32}, OnClicked: onDisconnect},
						},
					},
				},
			},
		},
	}
	if err := err.Create(); err != nil {
		log.Printf("主窗口创建失败: %v", err)
		walk.MsgBox(nil, "错误", err.Error(), walk.MsgBoxIconError)
		return
	}
	log.Println("主窗口创建成功，进入消息循环")
	mw.Show()
	if len(os.Args) > 1 && os.Args[1] == "-autostart" { // 测试钩子：自动走 Start Serve
		log.Println(`autostart 钩子触发`)
		onStartServe()
	}
	mw.Run()
	log.Println("消息循环退出")
}

var (
	joinFormComposite *walk.Composite
	hubComposite      *walk.Composite
)

func wgExePath() string {
	if p, err := exec.LookPath("wireguard.exe"); err == nil {
		return p
	}
	p := `C:\Program Files\WireGuard\wireguard.exe`
	if _, err := os.Stat(p); err == nil {
		return p
	}
	return ""
}

var lastLayoutW int

// —— Start Serve ——
func onStartServe() {
	defer func() {
		if msg := applog.Recover("onStartServe"); msg != "" {
			walk.MsgBox(mainMW(), "崩溃", msg, walk.MsgBoxIconError)
		}
	}()
	port, _ := strconv.Atoi(servePortEdit.Text())
	if port <= 0 {
		port = defaultPort
	}
	log.Printf("Start Serve 点击: port=%d", port)

	keys, err := confgen.GenerateKeyPair()
	if err != nil {
		log.Printf("密钥生成失败: %v", err)
		walk.MsgBox(mainMW(), "错误", "密钥生成失败: "+err.Error(), walk.MsgBoxIconError)
		return
	}
	srv = server.New(server.Options{Addr: ":" + strconv.Itoa(port), WGPort: port, ServerKey: keys.Public})
	go func() {
		if err := srv.Run(); err != nil {
			log.Printf("注册服务退出: %v", err)
		}
	}()
	log.Printf("注册服务监听 :%d，公钥 %s", port, keys.Public)

	// 尽力安装服务端隧道（需管理员 + wireguard.exe）
	if wg := wgExePath(); wg != "" {
		confFile := filepath.Join(os.TempDir(), "vlan-hub.conf")
		cfg := confgen.Config{Private: keys.Private, Address: serverVPNIP + "/24", ListenPort: port}
		os.WriteFile(confFile, []byte(cfg.Render()), 0600)
		go exec.Command(wg, "/installtunnelservice", confFile).CombinedOutput()
	}

	// 左栏切 Hub，显示折叠钮
	joinFormComposite.SetVisible(false)
	hubComposite.SetVisible(true)
	collapseBtn.SetVisible(true)
	hubShown = true
	mode = "serve"
	refreshHub()
	startHubPoll()
}

var hubPollOnce sync.Once

// startHubPoll 改为 UI 线程 SetTimer，见 ui_pump.go
func startHubPoll() {
	startHubUITimer()
}

func mainMW() *walk.MainWindow { return mainWin }

func refreshHub() {
	if srv == nil || hubText == nil {
		return
	}
	rows := srv.Members()
	var b strings.Builder
	if len(rows) == 0 {
		b.WriteString("（暂无成员）")
	}
	for _, r := range rows {
		fmt.Fprintf(&b, "%s    %s    %s\r\n", r.ID, r.VPNIP, r.Endpoint)
	}
	hubText.SetText(b.String())
}

func onRowDelete() { rowAction(false) }
func onRowBan()    { rowAction(true) }

func rowAction(ban bool) {
	if srv == nil {
		return
	}
	pk := pubEdit.Text()
	if pk == "" {
		return
	}
	if ban {
		srv.Ban(pk)
	} else {
		srv.Remove(pk)
	}
	pubEdit.SetText("")
	refreshHub()
}

// —— 折叠：关掉当前侧的「功能面板」，恢复该侧原始表单（serve: hub→join表单+停服；join: 状态→serve表单+断开）——
func onCollapse() {
	defer func() {
		if msg := applog.Recover("onCollapse"); msg != "" {
			walk.MsgBox(mainMW(), "崩溃", msg, walk.MsgBoxIconError)
		}
	}()
	collapsed = !collapsed
	collapseBtn.SetText(map[bool]string{true: "<<", false: ">>"}[collapsed])

	if mode == "serve" {
		if collapsed {
			hubComposite.SetVisible(false)
			joinFormComposite.SetVisible(true) // 左栏恢复 Join Server 表单
			if srv != nil {
				srv.Stop() // 关闭端口
				log.Println("折叠: 已关闭监听端口")
			}
		} else {
			joinFormComposite.SetVisible(false)
			hubComposite.SetVisible(true)
			if srv != nil {
				go func() {
					if err := srv.Run(); err != nil && err.Error() != "http: Server closed" {
						log.Printf("重新监听失败: %v", err)
					}
				}()
			}
			refreshHub()
		}
		return
	}

	// join 模式：右栏状态面板 ↔ Start Serve 表单
	if collapsed {
		joinInfoComposite.SetVisible(false)
		serveComposite.SetVisible(true)
		if joinH != nil {
			joinH.Stop() // 断开连接
			log.Println("折叠: 已断开组网")
		}
	} else if lastJoinOpts.ServerAddr != "" {
		// 展开恢复：用上次参数重新入网
		serveComposite.SetVisible(false)
		joinInfoComposite.SetVisible(true)
		go func() {
			h, err := client.Start(lastJoinOpts)
			if err != nil {
				log.Printf("重新入网失败: %v", err)
				mainMW().Synchronize(func() {
					joinInfoComposite.SetVisible(false)
					serveComposite.SetVisible(true)
					collapseBtn.SetVisible(false)
					collapsed = false
					collapseBtn.SetText(">>")
					mode = "idle"
					walk.MsgBox(mainMW(), "重新入网失败", err.Error(), walk.MsgBoxIconError)
				})
				return
			}
			joinH = h
			startJoinStatus(h)
		}()
	} else {
		joinInfoComposite.SetVisible(false)
		serveComposite.SetVisible(true)
		collapseBtn.SetVisible(false)
		mode = "idle"
	}
}

// —— Join Serve ——
func onJoinServe() {
	defer func() {
		if msg := applog.Recover("onJoinServe"); msg != "" {
			walk.MsgBox(mainMW(), "崩溃", msg, walk.MsgBoxIconError)
		}
	}()
	ip := ipEdit.Text()
	port := portEdit.Text()
	if ip == "" {
		walk.MsgBox(mainMW(), "提示", "请填写服务器 IP", walk.MsgBoxIconWarning)
		return
	}
	if port == "" {
		port = strconv.Itoa(defaultPort)
	}
	addr := net.JoinHostPort(ip, port)
	id := nickEdit.Text()
	log.Printf("Join Server 点击: %s id=%s", addr, id)
	joinBtn.SetEnabled(false)

	lastJoinOpts = client.Options{
		ServerAddr: "http://" + addr,
		ID:         id,
		WGPort:     defaultWG,
		TunnelName: "vlan-client",
	}

	go func() {
		h, err := client.Start(lastJoinOpts)
		mainMW().Synchronize(func() { joinBtn.SetEnabled(true) })
		if err != nil {
			log.Printf("Join 失败: %v", err)
			mainMW().Synchronize(func() {
				walk.MsgBox(mainMW(), "Join 失败", err.Error(), walk.MsgBoxIconError)
			})
			return
		}
		joinH = h
		mode = "join"
		mainMW().Synchronize(func() {
			// 右栏切状态面板
			serveComposite.SetVisible(false)
			joinInfoComposite.SetVisible(true)
		})
		startJoinStatus(h)
	}()
}

// startJoinStatus 周期刷新右栏状态面板（延迟/端口状态/成员数）。
func startJoinStatus(h *client.Handle) {
	go func() {
		for {
			select {
			case <-h.Done():
				mainMW().Synchronize(func() {
					if joinH == h { // 会话结束，右栏切回 Start Serve
						joinInfoComposite.SetVisible(false)
						serveComposite.SetVisible(true)
						joinH = nil
					}
				})
				return
			default:
			}
			latency, err := h.Ping()
			sv := h.ServerInfo()
			mainMW().Synchronize(func() {
				lblServer.SetText("服务器: " + sv.Endpoint + "  (" + shortKey(sv.PublicKey) + ")")
				lblSelf.SetText("我的内网 IP: " + h.Self().VPNIP + "  ·  昵称: " + h.Self().ID)
				lblMembers.SetText("成员数: " + strconv.Itoa(len(h.Peers())+1))
				if err != nil {
					lblLatency.SetText("延迟: 无法连接")
					lblLatency.SetTextColor(walk.Color(colorBad))
					lblPort.SetText("端口状态: 禁用")
					lblPort.SetTextColor(walk.Color(colorBad))
				} else {
					lblLatency.SetText("延迟: " + strconv.FormatInt(latency.Milliseconds(), 10) + " ms")
					lblLatency.SetTextColor(walk.Color(colorOK))
					lblPort.SetText("端口状态: 畅通")
					lblPort.SetTextColor(walk.Color(colorOK))
				}
			})
			time.Sleep(3 * time.Second)
		}
	}()
}

func onDisconnect() {
	if joinH != nil {
		joinH.Stop()
	}
}

func shortKey(k string) string {
	if len(k) > 12 {
		return k[:12] + "…"
	}
	return k
}

var (
	leftPanel, rightPanel, midPanel *walk.Composite
	mainWin                         *walk.MainWindow
)
