// Package server 公网服务器：注册服务 + 成员表 + 事件推送（长轮询）。
package server

import (
	"encoding/json"
	"fmt"
	"net"
	"net/http"
	"sort"
	"strconv"
	"strings"
	"sync"
	"time"

	"vlan/api"
)

// Options 服务端参数。
type Options struct {
	Addr        string // 监听地址，如 ":8080"
	ServerIP    string // 服务端公网 IP（拼 Endpoint 用），空则自动探测
	WGPort      int    // 服务端 WireGuard UDP 端口
	ServerKey   string // 服务端公钥
}

// Server 注册服务。
type Server struct {
	opts Options

	httpSrv *http.Server
	mu      sync.Mutex
	members map[string]*api.Member // key: publicKey
	banned  map[string]bool        // key: publicKey 与 来源IP 双记
	nextIP  int                    // 地址池游标，从 .2 起
	seq     int64
	pending map[int64]*api.Event // 最近事件，供长轮询
	waiters map[chan struct{}]struct{}
}

// New 创建服务端。
func New(opts Options) *Server {
	return &Server{
		opts:    opts,
		members: map[string]*api.Member{},
		banned:  map[string]bool{},
		nextIP:  api.PoolFirstHost,
		pending: map[int64]*api.Event{},
		waiters: map[chan struct{}]struct{}{},
	}
}

// Run 启动 HTTP 服务（阻塞）。用变量接 err 才能被 Stop 打断。
func (s *Server) Run() error {
	mux := http.NewServeMux()
	mux.HandleFunc("/ping", func(w http.ResponseWriter, r *http.Request) {
		writeJSON(w, http.StatusOK, map[string]string{"pong": "1"})
	})
	mux.HandleFunc("/join", s.handleJoin)
	mux.HandleFunc("/leave", s.handleLeave)
	mux.HandleFunc("/events", s.handleEvents)
	mux.HandleFunc("/members", s.handleMembers) // 本机管理 UI 拉列表
	mux.HandleFunc("/ban", s.handleBan)
	mux.HandleFunc("/delete", s.handleDelete)
	s.httpSrv = &http.Server{Addr: s.opts.Addr, Handler: mux}
	err := s.httpSrv.ListenAndServe()
	if err == http.ErrServerClosed {
		err = nil
	}
	return err
}

// Stop 关闭监听端口（收起面板用）。
func (s *Server) Stop() {
	if s.httpSrv != nil {
		s.httpSrv.Close() // 立即断，长轮询也会被掐断
	}
}

func writeJSON(w http.ResponseWriter, code int, v interface{}) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(code)
	json.NewEncoder(w).Encode(v)
}

func validKey(k string) bool {
	return len(k) == 44 && strings.HasSuffix(k, "=")
}

func (s *Server) broadcast(t string, m *api.Member) {
	s.seq++
	ev := &api.Event{V: api.ProtoVersion, Seq: s.seq, Type: t, Member: *m}
	s.pending[ev.Seq] = ev
	if len(s.pending) > 256 { // 只留最近 256 条
		minSeq := s.seq - 256
		for k := range s.pending {
			if k < minSeq {
				delete(s.pending, k)
			}
		}
	}
	for ch := range s.waiters {
		close(ch)
	}
	s.waiters = map[chan struct{}]struct{}{}
}

// Members 当前成员快照。
func (s *Server) Members() []api.Member {
	s.mu.Lock()
	defer s.mu.Unlock()
	out := make([]api.Member, 0, len(s.members))
	for _, m := range s.members {
		out = append(out, *m)
	}
	sort.Slice(out, func(i, j int) bool { return out[i].VPNIP < out[j].VPNIP })
	return out
}

// Remove 管理端删除成员（广播 remove）。
func (s *Server) Remove(publicKey string) bool {
	s.mu.Lock()
	defer s.mu.Unlock()
	m, ok := s.members[publicKey]
	if !ok {
		return false
	}
	delete(s.members, publicKey)
	s.broadcast(api.EventRemove, m)
	return true
}

// Ban 封禁（key+IP 双记，广播 kick）。
func (s *Server) Ban(publicKey string) bool {
	s.mu.Lock()
	defer s.mu.Unlock()
	m, ok := s.members[publicKey]
	if !ok {
		return false
	}
	s.banned[publicKey] = true
	if ip, _, err := net.SplitHostPort(m.Endpoint); err == nil {
		s.banned[ip] = true
	}
	delete(s.members, publicKey)
	s.broadcast(api.EventKick, m)
	return true
}

func (s *Server) serverEndpoint() string {
	ip := s.opts.ServerIP
	if ip == "" {
		// 尽力探测公网出口；失败则留空，客户端自行用注册地址拼
		return ""
	}
	return net.JoinHostPort(ip, strconv.Itoa(s.opts.WGPort))
}

func (s *Server) handleJoin(w http.ResponseWriter, r *http.Request) {
	var req api.JoinRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil || req.V != api.ProtoVersion || !validKey(req.PublicKey) {
		writeJSON(w, http.StatusBadRequest, api.ErrorResponse{Error: "bad_request"})
		return
	}
	srcIP, _, _ := net.SplitHostPort(r.RemoteAddr)
	port := req.WGPort
	if port <= 0 {
		port = api.DefaultWGPort
	}

	s.mu.Lock()
	if s.banned[req.PublicKey] || s.banned[srcIP] {
		s.mu.Unlock()
		writeJSON(w, http.StatusForbidden, api.ErrorResponse{Error: "banned"})
		return
	}
	// 幂等：同 key 重复 Join = 更新
	if m, ok := s.members[req.PublicKey]; ok {
		m.Endpoint = net.JoinHostPort(srcIP, strconv.Itoa(port))
		resp := s.buildJoinResponseLocked(m)
		s.mu.Unlock()
		writeJSON(w, http.StatusOK, resp)
		return
	}
	if s.nextIP > api.PoolLastHost {
		s.mu.Unlock()
		writeJSON(w, http.StatusInsufficientStorage, api.ErrorResponse{Error: "pool_exhausted"})
		return
	}
	id := req.ID
	if id == "" {
		id = fmt.Sprintf("anon-%08x", time.Now().UnixNano()&0xffffffff)
	}
	// ID 冲突加后缀
	for {
		taken := false
		for _, m := range s.members {
			if m.ID == id {
				taken = true
				break
			}
		}
		if !taken {
			break
		}
		id += "-2"
	}
	m := &api.Member{
		ID:        id,
		PublicKey: req.PublicKey,
		VPNIP:     fmt.Sprintf("10.84.111.%d", s.nextIP),
		Endpoint:  net.JoinHostPort(srcIP, strconv.Itoa(port)),
		JoinedAt:  time.Now().Unix(),
	}
	s.nextIP++
	s.members[req.PublicKey] = m
	resp := s.buildJoinResponseLocked(m)
	s.broadcast(api.EventAdd, m) // 通知所有老成员
	s.mu.Unlock()
	writeJSON(w, http.StatusOK, resp)
}

// buildJoinResponseLocked 组装 Join 响应（持锁调用）。
func (s *Server) buildJoinResponseLocked(self *api.Member) api.JoinResponse {
	peers := make([]api.Member, 0, len(s.members)-1)
	for _, m := range s.members {
		if m.PublicKey != self.PublicKey {
			peers = append(peers, *m)
		}
	}
	return api.JoinResponse{
		V:   api.ProtoVersion,
		You: *self,
		Server: api.PeerInfo{
			PublicKey: s.opts.ServerKey,
			VPNIP:     "10.84.111.1",
			Endpoint:  s.serverEndpoint(),
		},
		Peers: peers,
	}
}

func (s *Server) handleLeave(w http.ResponseWriter, r *http.Request) {
	var req api.LeaveRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil || !validKey(req.PublicKey) {
		writeJSON(w, http.StatusBadRequest, api.ErrorResponse{Error: "bad_request"})
		return
	}
	s.Remove(req.PublicKey) // 幂等
	writeJSON(w, http.StatusOK, api.ErrorResponse{})
}

func (s *Server) handleEvents(w http.ResponseWriter, r *http.Request) {
	since, _ := strconv.ParseInt(r.URL.Query().Get("since"), 10, 64)
	s.mu.Lock()
	// 落后太多 → 让客户端重新 Join
	if since > 0 && since < s.seq-256 {
		s.mu.Unlock()
		writeJSON(w, http.StatusGone, api.ErrorResponse{Error: "resync"})
		return
	}
	if ev, ok := s.pending[since+1]; ok {
		s.mu.Unlock()
		writeJSON(w, http.StatusOK, ev)
		return
	}
	ch := make(chan struct{})
	s.waiters[ch] = struct{}{}
	s.mu.Unlock()

	select {
	case <-ch: // 有新事件
	case <-time.After(25 * time.Second): // 心跳
	}
	s.mu.Lock()
	ev, ok := s.pending[since+1]
	s.mu.Unlock()
	if !ok {
		w.WriteHeader(http.StatusNoContent)
		return
	}
	writeJSON(w, http.StatusOK, ev)
}

func (s *Server) handleMembers(w http.ResponseWriter, r *http.Request) {
	writeJSON(w, http.StatusOK, s.Members())
}

func (s *Server) handleBan(w http.ResponseWriter, r *http.Request) {
	var req api.LeaveRequest
	json.NewDecoder(r.Body).Decode(&req)
	writeJSON(w, http.StatusOK, api.ErrorResponse{Error: map[bool]string{true: "", false: "not_found"}[s.Ban(req.PublicKey)]})
}

func (s *Server) handleDelete(w http.ResponseWriter, r *http.Request) {
	var req api.LeaveRequest
	json.NewDecoder(r.Body).Decode(&req)
	writeJSON(w, http.StatusOK, api.ErrorResponse{Error: map[bool]string{true: "", false: "not_found"}[s.Remove(req.PublicKey)]})
}
