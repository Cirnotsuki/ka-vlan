// Package applog 文件日志：GUI 程序没有控制台，日志落 %LOCALAPPDATA%\vlan\logs\。
package applog

import (
	"fmt"
	"io"
	"log"
	"os"
	"path/filepath"
	"runtime/debug"
	"time"
)

// LogDir 当前日志目录。
var LogDir string

// Init 初始化全局 log 输出到按天滚动的日志文件，返回日志文件路径。
func Init() string {
	LogDir = filepath.Join(os.Getenv("LOCALAPPDATA"), "vlan", "logs")
	os.MkdirAll(LogDir, 0700)
	name := time.Now().Format("2006-01-02") + ".log"
	f, err := os.OpenFile(filepath.Join(LogDir, name), os.O_CREATE|os.O_APPEND|os.O_WRONLY, 0600)
	if err != nil {
		// 连日志目录都写不了时退回临时目录
		LogDir = os.TempDir()
		f, _ = os.Create(filepath.Join(LogDir, "vlan-app.log"))
	}
	log.SetFlags(log.LstdFlags | log.Lshortfile)
	log.SetOutput(io.MultiWriter(f))
	log.Printf("=== 启动 ===")
	return filepath.Join(LogDir, name)
}

// Path 当前日志文件路径。
func Path() string {
	return filepath.Join(LogDir, time.Now().Format("2006-01-02")+".log")
}

// Recover 在 defer 里调用：捕获 panic 写日志。返回非空说明发生了 panic，调用方负责弹框展示。
func Recover(where string) string {
	r := recover()
	if r == nil {
		return ""
	}
	log.Printf("PANIC in %s: %v\n%s", where, r, debug.Stack())
	return fmt.Sprintf("%s 发生崩溃: %v\n详情见日志 %s", where, r, Path())
}
