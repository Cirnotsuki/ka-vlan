// vlanhub 公网服务器端入口：Start Serve → 注册服务 + 管理列表。
package main

import (
	"bufio"
	"bytes"
	"encoding/json"
	"flag"
	"fmt"
	"io"
	"log"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"strconv"
	"strings"
	"time"

	"vlan/api"
	"vlan/confgen"
	"vlan/server"
)

func main() {
	addr := flag.String("addr", "127.0.0.1:8080", "注册服务监听地址")
	wgPort := flag.Int("wgport", api.DefaultWGPort, "服务端 WireGuard UDP 端口")
	ip := flag.String("ip", "", "本机公网 IP（拼 Endpoint，留空则客户端用注册地址拼）")
	flag.Parse()

	fmt.Println("=== VLAN Hub · Start Serve ===")

	// 1. 密钥对 + 服务端自身 wg.conf
	keys, err := confgen.GenerateKeyPair()
	if err != nil {
		log.Fatal(err)
	}
	svConf := confgen.Config{Private: keys.Private, Address: "10.84.111.1/24", ListenPort: *wgPort}
	confFile := "vlan-hub.conf"
	if err := os.WriteFile(confFile, []byte(svConf.Render()), 0600); err != nil {
		log.Fatal(err)
	}
	fmt.Printf("服务端公钥: %s\n已生成 %s\n", keys.Public, abs(confFile))

	// 2. 安装隧道服务（需管理员；失败则提示手动装）
	wgExe, _ := exec.LookPath("wireguard.exe")
	if wgExe != "" {
		out, err := exec.Command(wgExe, "/installtunnelservice", abs(confFile)).CombinedOutput()
		if err != nil {
			fmt.Printf("自动安装隧道失败（可手动执行: wireguard.exe /installtunnelservice %s）: %v\n%s\n", abs(confFile), err, out)
		} else {
			fmt.Println("隧道服务已安装")
		}
	} else {
		fmt.Println("未找到 wireguard.exe，请手动安装隧道:", abs(confFile))
	}

	// 3. 注册服务
	srv := server.New(server.Options{Addr: *addr, ServerIP: *ip, WGPort: *wgPort, ServerKey: keys.Public})
	go func() {
		if err := srv.Run(); err != nil {
			log.Fatal(err)
		}
	}()
	fmt.Printf("注册服务监听 %s\n", *addr)

	// 4. 管理列表（控制台版，GUI 后补）：每 10s 刷新打印
	pub := keys.Public
	go func() {
		last := -1
		for {
			ms := srv.Members()
			if len(ms) != last {
				fmt.Printf("\n--- 成员列表 (%d) ---\n", len(ms))
				for _, m := range ms {
					fmt.Printf("  %-16s %-14s %s\n", m.ID, m.VPNIP, m.Endpoint)
				}
				last = len(ms)
			}
			_ = pub
			time.Sleep(10 * time.Second)
		}
	}()

	// 5. 管理命令：del <publicKey> / ban <publicKey> / members / quit
	adminURL := "http://" + *addr
	sc := bufio.NewScanner(os.Stdin)
	for sc.Scan() {
		fs := strings.Fields(sc.Text())
		if len(fs) == 0 {
			continue
		}
		switch fs[0] {
		case "del", "ban":
			if len(fs) != 2 {
				fmt.Println("用法:", fs[0], "<publicKey>")
				continue
			}
			body, _ := json.Marshal(api.LeaveRequest{V: api.ProtoVersion, PublicKey: fs[1]})
			path := "/delete"
			if fs[0] == "ban" {
				path = "/ban"
			}
			resp, err := http.Post(adminURL+path, "application/json", bytes.NewReader(body))
			if err != nil {
				fmt.Println("失败:", err)
				continue
			}
			resp.Body.Close()
			fmt.Println("已完成")
		case "members":
			resp, err := http.Get(adminURL + "/members")
			if err != nil {
				fmt.Println("失败:", err)
				continue
			}
			data, _ := io.ReadAll(resp.Body)
			resp.Body.Close()
			fmt.Println(string(data))
		case "quit":
			return
		default:
			fmt.Println("命令: del <key> | ban <key> | members | quit")
		}
	}
}

func abs(p string) string {
	a, err := filepath.Abs(p)
	if err != nil {
		return p
	}
	return a
}

var _ = strconv.Itoa
