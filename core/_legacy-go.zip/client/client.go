// Package client Join 端：注册、生成配置、驱动 wireguard.exe、事件循环。
package client

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"log"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"strconv"
	"sync"
	"time"

	"vlan/api"
	"vlan/confgen"
)

// Options 客户端参数。
type Options struct {
	ServerAddr string // 服务器 地址:8080
	ID         string // 空 = 匿名
	WGPort     int    // 本地 WireGuard UDP 端口
	WireguardExe string // wireguard.exe 路径，默认从 PATH 找
	TunnelName string // 隧道服务名，默认 vlan-client
}

type session struct {
	opts  Options
	keys  confgen.KeyPair
	self  api.Member
	resp  api.JoinResponse
	since int64
}

// exePath 找 wireguard.exe：不能用 log.Fatal —— 那是库代码，会直接把整个进程（vlancore 的 HTTP 服务）带走
func exePath(opts *Options) (string, error) {
	if opts.WireguardExe != "" {
		return opts.WireguardExe, nil
	}
	p, err := exec.LookPath("wireguard.exe")
	if err != nil {
		return "", fmt.Errorf("找不到 wireguard.exe（PATH 里没有），请在选项里用 WireguardExe 指定完整路径")
	}
	return p, nil
}

func confPath(name string) string {
	dir, err := os.UserConfigDir()
	if err != nil {
		dir = "."
	}
	d := filepath.Join(dir, "vlan")
	os.MkdirAll(d, 0700)
	return filepath.Join(d, name+".conf")
}

// install 装载隧道服务（wireguard.exe /installtunnelservice，需管理员）。
func install(opts *Options, conf string) error {
	wgExe, err := exePath(opts)
	if err != nil {
		return err
	}
	p := confPath(opts.TunnelName)
	if err := os.WriteFile(p, []byte(conf), 0600); err != nil {
		return err
	}
	cmd := exec.Command(wgExe, "/installtunnelservice", p)
	out, err := cmd.CombinedOutput()
	if err != nil {
		return fmt.Errorf("installtunnelservice: %v\n%s", err, out)
	}
	return nil
}

func uninstall(opts *Options) error {
	wgExe, err := exePath(opts)
	if err != nil {
		return err
	}
	cmd := exec.Command(wgExe, "/uninstalltunnelservice", opts.TunnelName)
	out, err := cmd.CombinedOutput()
	if err != nil && !bytes.Contains(out, []byte("already")) {
		return fmt.Errorf("uninstalltunnelservice: %v\n%s", err, out)
	}
	return nil
}

// reinstallPeer 用最新成员表重建本地 conf 并重装服务（秒级断连）。
func (s *session) reinstallPeer() error {
	cfg := confgen.Config{
		Private:    s.keys.Private,
		Address:    s.self.VPNIP + "/24",
		ListenPort: s.opts.WGPort,
	}
	if s.opts.WGPort <= 0 {
		cfg.ListenPort = api.DefaultWGPort
	}
	sv := s.resp.Server
	cfg.Peers = append(cfg.Peers, confgen.Peer{
		PublicKey:           sv.PublicKey,
		AllowedIPs:          sv.VPNIP + "/32",
		Endpoint:            sv.Endpoint,
		PersistentKeepalive: api.KeepaliveSecs,
	})
	for _, m := range s.resp.Peers {
		cfg.Peers = append(cfg.Peers, confgen.Peer{
			PublicKey:           m.PublicKey,
			AllowedIPs:          m.VPNIP + "/32",
			Endpoint:            m.Endpoint,
			PersistentKeepalive: api.KeepaliveSecs,
		})
	}
	uninstall(&s.opts)
	return install(&s.opts, cfg.Render())
}

// Join 执行一次入网并阻塞在事件循环（CLI 用）。GUI 用 Start。
func Join(opts Options) error {
	h, err := Start(opts)
	if err != nil {
		return err
	}
	<-h.Done()
	return h.Err()
}

// Handle 在网的会话句柄。
type Handle struct {
	mu   sync.Mutex
	s    *session
	done chan struct{}
	err  error
	stop sync.Once
}

func (h *Handle) Done() <-chan struct{} { return h.done }
func (h *Handle) Err() error            { h.mu.Lock(); defer h.mu.Unlock(); return h.err }
func (h *Handle) Self() api.Member {
	h.mu.Lock()
	defer h.mu.Unlock()
	return h.s.self
}
func (h *Handle) Peers() []api.Member {
	h.mu.Lock()
	defer h.mu.Unlock()
	return append([]api.Member(nil), h.s.resp.Peers...)
}
func (h *Handle) ServerInfo() api.PeerInfo {
	h.mu.Lock()
	defer h.mu.Unlock()
	return h.s.resp.Server
}

// Ping 探测服务端 RTT。
func (h *Handle) Ping() (time.Duration, error) {
	t0 := time.Now()
	resp, err := http.Get(h.s.opts.ServerAddr + "/ping")
	if err != nil {
		return 0, err
	}
	resp.Body.Close()
	return time.Since(t0), nil
}

// Stop 主动离网：发 leave、卸载隧道、结束事件循环。
func (h *Handle) Stop() {
	h.stop.Do(func() {
		body, _ := json.Marshal(api.LeaveRequest{V: api.ProtoVersion, PublicKey: h.s.keys.Public})
		if resp, err := http.Post(h.s.opts.ServerAddr+"/leave", "application/json", bytes.NewReader(body)); err == nil {
			resp.Body.Close()
		}
		uninstall(&h.s.opts)
		h.mu.Lock()
		if h.err == nil {
			h.err = fmt.Errorf("已主动离网")
		}
		h.mu.Unlock()
		close(h.done)
	})
}

// Start 入网（非阻塞）：Join 成功后后台跑事件循环。
func Start(opts Options) (*Handle, error) {
	if opts.TunnelName == "" {
		opts.TunnelName = "vlan-client"
	}
	s := &session{opts: opts}

	keys, err := confgen.GenerateKeyPair()
	if err != nil {
		return nil, err
	}
	s.keys = keys

	req := api.JoinRequest{V: api.ProtoVersion, PublicKey: keys.Public, ID: opts.ID, WGPort: opts.WGPort}
	body, _ := json.Marshal(req)
	httpResp, err := http.Post(opts.ServerAddr+"/join", "application/json", bytes.NewReader(body))
	if err != nil {
		return nil, err
	}
	defer httpResp.Body.Close()
	data, _ := io.ReadAll(httpResp.Body)
	if httpResp.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("join 被拒绝: %d %s", httpResp.StatusCode, string(data))
	}
	if err := json.Unmarshal(data, &s.resp); err != nil {
		return nil, err
	}
	s.self = s.resp.You
	log.Printf("已入网: ID=%s 内网IP=%s 成员数=%d", s.self.ID, s.self.VPNIP, len(s.resp.Peers)+1)

	if err := s.reinstallPeer(); err != nil {
		return nil, err
	}

	h := &Handle{s: s, done: make(chan struct{})}
	go h.loop()
	return h, nil
}

func (h *Handle) loop() {
	for {
		select {
		case <-h.done:
			return
		default:
		}
		ev, resync, err := h.s.pollEvent()
		if err != nil {
			h.fail(err)
			return
		}
		if resync { // 落后太多 → 重新 Join
			h.mu.Lock()
			opts := h.s.opts
			id := h.s.self.ID
			h.mu.Unlock()
			opts.ID = id
			nh, err := Start(opts)
			if err != nil {
				h.fail(err)
				return
			}
			h.mu.Lock()
			h.s = nh.s
			h.mu.Unlock()
			continue
		}
		if ev == nil {
			continue // 心跳
		}
		h.applyEvent(ev)
	}
}

func (h *Handle) fail(err error) {
	h.mu.Lock()
	if h.err == nil {
		h.err = err
	}
	h.mu.Unlock()
	uninstall(&h.s.opts)
	h.stop.Do(func() { close(h.done) })
}

func (h *Handle) applyEvent(ev *api.Event) {
	h.mu.Lock()
	s := h.s
	switch ev.Type {
	case api.EventAdd:
		s.resp.Peers = append(s.resp.Peers, ev.Member)
	case api.EventRemove:
		out := s.resp.Peers[:0]
		for _, m := range s.resp.Peers {
			if m.PublicKey != ev.Member.PublicKey {
				out = append(out, m)
			}
		}
		s.resp.Peers = out
	case api.EventKick:
		out := s.resp.Peers[:0]
		for _, m := range s.resp.Peers {
			if m.PublicKey != ev.Member.PublicKey {
				out = append(out, m)
			}
		}
		s.resp.Peers = out
		if ev.Member.PublicKey == s.keys.Public {
			h.mu.Unlock()
			uninstall(&s.opts)
			h.fail(fmt.Errorf("已被封禁，退出组网"))
			return
		}
	}
	h.mu.Unlock()
	if err := h.s.reinstallPeer(); err != nil {
		log.Printf("重装隧道失败: %v", err)
	}
}

// pollEvent 拉一条事件；返回 (事件, 是否需要 resync, err)。
func (s *session) pollEvent() (*api.Event, bool, error) {
	url := s.opts.ServerAddr + "/events?since=" + strconv.FormatInt(s.since, 10)
	resp, err := http.Get(url)
	if err != nil {
		time.Sleep(3 * time.Second) // 网络抖动，退避重试
		return nil, false, nil
	}
	defer resp.Body.Close()
	switch resp.StatusCode {
	case http.StatusNoContent:
		return nil, false, nil
	case http.StatusGone:
		return nil, true, nil
	case http.StatusOK:
		var ev api.Event
		data, _ := io.ReadAll(resp.Body)
		if err := json.Unmarshal(data, &ev); err != nil {
			return nil, false, err
		}
		s.since = ev.Seq
		return &ev, false, nil
	default:
		return nil, false, fmt.Errorf("events 异常状态: %d", resp.StatusCode)
	}
}
