// Package api 注册/推送协议的公共类型（与 docs/PROTOCOL.md 对应）。
package api

// JoinRequest POST /join。
type JoinRequest struct {
	V         int    `json:"v"`
	PublicKey string `json:"public_key"`
	ID        string `json:"id,omitempty"`
	WGPort    int    `json:"wg_port"`
}

// Member 成员条目。
type Member struct {
	ID        string `json:"id"`
	PublicKey string `json:"public_key"`
	VPNIP     string `json:"vpn_ip"`
	Endpoint  string `json:"endpoint"`
	JoinedAt  int64  `json:"joined_at"`
}

// JoinResponse POST /join 的 200 响应。
type JoinResponse struct {
	V      int      `json:"v"`
	You    Member   `json:"you"`
	Server PeerInfo `json:"server"`
	Peers  []Member `json:"peers"`
}

// PeerInfo 服务端自身信息。
type PeerInfo struct {
	PublicKey string `json:"public_key"`
	VPNIP     string `json:"vpn_ip"`
	Endpoint  string `json:"endpoint"`
}

// ErrorResponse 错误响应。
type ErrorResponse struct {
	Error string `json:"error"`
}

// 事件类型。
const (
	EventAdd    = "add"
	EventRemove = "remove"
	EventKick   = "kick"
)

// Event /events 推送信封。
type Event struct {
	V      int    `json:"v"`
	Seq    int64  `json:"seq"`
	Type   string `json:"type"`
	Member Member `json:"member"`
}

// LeaveRequest POST /leave。
type LeaveRequest struct {
	V         int    `json:"v"`
	PublicKey string `json:"public_key"`
}

// 协议版本与默认常量。
const (
	ProtoVersion  = 1
	DefaultWGPort = 1212 // 注册(TCP)与 WireGuard(UDP) 同号不同协议
	KeepaliveSecs = 25
	PoolFirstHost = 2 // .1 固定给服务端，成员从 .2 开始
	PoolLastHost  = 254
)
