// vlanjoin 客户端入口：Join Serve。
package main

import (
	"flag"
	"log"

	"vlan/client"
)

func main() {
	server := flag.String("server", "", "服务器 地址:8080（必填）")
	id := flag.String("id", "", "ID，留空 = 匿名")
	wgPort := flag.Int("wgport", 51820, "本地 WireGuard UDP 端口")
	wgExe := flag.String("wireguard", "", "wireguard.exe 路径，默认从 PATH 找")
	flag.Parse()

	if *server == "" {
		log.Fatal("用法: vlanjoin -server <地址:8080> [-id 匿名ID] [-wgport 51820]")
	}
	opts := client.Options{
		ServerAddr:   "http://" + *server,
		ID:           *id,
		WGPort:       *wgPort,
		WireguardExe: *wgExe,
		TunnelName:   "vlan-client",
	}
	log.SetFlags(0)
	if err := client.Join(opts); err != nil {
		log.Fatal(err)
	}
}
