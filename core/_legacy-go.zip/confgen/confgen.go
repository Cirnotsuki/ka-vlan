// Package confgen 生成 WireGuard 配置文件与密钥对。
package confgen

import (
	"crypto/rand"
	"encoding/base64"
	"fmt"
	"strings"

	"golang.org/x/crypto/curve25519"
)

// KeyPair 一组 X25519 密钥（base64，可直接进 wg.conf）。
type KeyPair struct {
	Private string
	Public  string
}

// GenerateKeyPair 生成一组 WireGuard 密钥。
func GenerateKeyPair() (KeyPair, error) {
	var priv [32]byte
	if _, err := rand.Read(priv[:]); err != nil {
		return KeyPair{}, err
	}
	priv[0] &= 248
	priv[31] &= 127
	priv[31] |= 64
	var pub [32]byte
	curve25519.ScalarBaseMult(&pub, &priv)
	return KeyPair{
		Private: base64.StdEncoding.EncodeToString(priv[:]),
		Public:  base64.StdEncoding.EncodeToString(pub[:]),
	}, nil
}

// Peer 一条 [Peer] 段。
type Peer struct {
	PublicKey           string
	AllowedIPs          string // 如 "10.84.111.5/32"
	Endpoint            string // 可空
	PersistentKeepalive int    // 0 表示不写
}

// Config 一份完整 wg.conf。
type Config struct {
	Private    string
	Address    string // 如 "10.84.111.5/24"
	ListenPort int
	Peers      []Peer
}

// Render 输出标准 wg.conf 文本。
func (c *Config) Render() string {
	var b strings.Builder
	fmt.Fprintf(&b, "[Interface]\nPrivateKey = %s\nAddress = %s\n", c.Private, c.Address)
	if c.ListenPort > 0 {
		fmt.Fprintf(&b, "ListenPort = %d\n", c.ListenPort)
	}
	for _, p := range c.Peers {
		fmt.Fprintf(&b, "\n[Peer]\nPublicKey = %s\nAllowedIPs = %s\n", p.PublicKey, p.AllowedIPs)
		if p.Endpoint != "" {
			fmt.Fprintf(&b, "Endpoint = %s\n", p.Endpoint)
		}
		if p.PersistentKeepalive > 0 {
			fmt.Fprintf(&b, "PersistentKeepalive = %d\n", p.PersistentKeepalive)
		}
	}
	return b.String()
}
